from termcolor import colored

print(colored('~~~RAINBOW~~~', 'red'))
print(colored('~~~RAINBOW~~~', 'yellow'))
print(colored('~~~RAINBOW~~~', 'green'))
print(colored('~~~RAINBOW~~~', 'cyan'))
print(colored('~~~RAINBOW~~~', 'blue'))
print(colored('~~~RAINBOW~~~', 'magenta'))
