from primes import listPrimes


print(listPrimes(100))